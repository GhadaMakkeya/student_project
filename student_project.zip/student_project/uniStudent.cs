﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Project
{

    class uniStudent : Info, IStudent
    {
       
        List<string> tasks = new List<string>();
        
        public void Add_Task()
        {
            Console.WriteLine("=============");
            Console.Write("please enter the task you want to add:");
            tasks.Add(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("Done!");
        }

        public void Remove_Task()
        {
            Console.WriteLine("=============");
            Console.WriteLine("please enter the number of the task you want to remove:");
            for (int i = 0; i < tasks.Count; i++)
            {
                Console.WriteLine($"{i} {tasks[i]}");
            }
            int index = int.Parse(Console.ReadLine());
            tasks.RemoveAt(index);
            Console.WriteLine("Done!");
        }

        public void Show_Tasks()
        {
            Console.WriteLine("=============");
            Console.WriteLine("your tasks:");
            for (int i = 0; i < tasks.Count; i++)
            {
                Console.WriteLine($"{i + 1}- {tasks[i]}");
            }
        }

    }
}

