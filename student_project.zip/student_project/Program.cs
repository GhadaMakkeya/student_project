﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace OOP_Project
{
    class program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter 1 if you are a university student or 2 if you are a school student");
            int choice = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            while (choice != 1 || choice != 2)
            {
                if (choice == 1)
                {
                    Console.WriteLine("You selected university student!");
                    Thread.Sleep(1000);
                    Console.Clear();
                    uniStudent student = new uniStudent();

                    Console.WriteLine("Please enter your name");
                    student.name = Console.ReadLine();
                    Console.Clear();

                    Console.WriteLine("Please enter your uni ID, it should be 6 digits long");
                    int ID = Convert.ToInt32(Console.ReadLine());
                    while (!isValidID(ID))
                    {
                        Console.WriteLine("Invalid ID!");
                        Thread.Sleep(1000);
                        Console.Clear();
                        Console.WriteLine("Please try again");
                        ID = Convert.ToInt32(Console.ReadLine());
                    }
                    student.ID = ID;
                    Console.WriteLine("Valid!");
                    Console.Clear();

                    Console.WriteLine("Please enter your Email");
                    string email = Console.ReadLine();
                    while (!isValidEmail(email))
                    {
                        Console.WriteLine("Invalid Email!");
                        Thread.Sleep(1000);
                        Console.Clear();
                        Console.WriteLine("Please try again");
                        email = Console.ReadLine();
                        Console.Clear();
                    }
                    student.Email = email;
                    Console.WriteLine("Valid!");
                    Console.Clear();

                    Console.WriteLine("Please enter your password, it should be at least 8 characters long");
                    string Password = Console.ReadLine();
                    while (!isValidPassword(Password))
                    {
                        Console.WriteLine("Invalid Password!");
                        Thread.Sleep(1000);
                        Console.Clear();
                        Console.WriteLine("Please try again");
                        Password = Console.ReadLine();
                        Console.Clear();
                    }
                    student.password = Password;
                    Console.WriteLine("Valid!");
                    Console.Clear();
                    break;
                }
                else if (choice == 2)
                {
                    Console.WriteLine("You selected school student!");
                    schoolStudent student = new schoolStudent();
                }
                else
                    Console.WriteLine("Invalid option");
            }
            static bool isValidEmail(string email)
            {
                if (string.IsNullOrWhiteSpace(email))
                    return false;

                string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

                return Regex.IsMatch(email, pattern, RegexOptions.IgnoreCase);
            }
            static bool isValidPassword(string password)
            {
                if (string.IsNullOrWhiteSpace(password))
                    return false;
                if (password.Length < 8)
                    return false;
                if (!password.Any(char.IsUpper))
                    return false;
                if (!password.Any(char.IsLower))
                    return false;
                if (!password.Any(char.IsDigit))
                    return false;
                if (!Regex.IsMatch(password, @"[!@#$%^&*(),.?{}|<>]"))
                    return false;
                return true;
            }
            static bool isValidID(int ID)
            {
                if (ID < 0)
                    return false;
                if (ID.ToString().Length != 6)
                    return false;
                return true;
            }
        }
    }
}
    