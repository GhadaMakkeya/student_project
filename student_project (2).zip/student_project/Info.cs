﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace OOP_Project
{
    class Info
    {
        public string Name { get; set; }
        public string ID { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public void storeEmail()
        {
            File.WriteAllText($"{Name}_email.txt", Email);
        }
        public void storePassword()
        {
            File.WriteAllText($"{Name}_password.txt", Password);
        }
        public void storeID()
        {
            File.WriteAllText($"{Name}_ID.txt", ID);
        }

    }

 }

