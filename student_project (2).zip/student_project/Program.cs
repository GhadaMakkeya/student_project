﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Security.Cryptography.X509Certificates;
using Newtonsoft.Json;


namespace OOP_Project
{
    class program
    {
        static uniStudent uni_student;
        static schoolStudent school_student;
        static void Main(string[] args)
        {
            Console.Write("Please enter 1 if you are a university student or 2 if you are a school student:");
            int studiesChoice = Convert.ToInt32(Console.ReadLine());
            Thread.Sleep(1000);
            Console.Clear();
            string taskChoice = "";
            while (studiesChoice != 1 && studiesChoice != 2)
            {
                Console.WriteLine("Invalid choice!,Please enter 1 or 2");
                studiesChoice = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
            }

            if (studiesChoice == 1)
            {
                Console.WriteLine("You selected university student!");
                Console.ReadKey();
                Console.Clear();
                uni_student = new uniStudent();
                studentInputDetails(ref uni_student, ref school_student);
                choosingOption(ref uni_student, ref school_student);
                //=================//

            }
            else if (studiesChoice == 2)
            {
                Console.WriteLine("You selected school student!");
                school_student = new schoolStudent();
                Console.ReadKey();
                Console.Clear();
                studentInputDetails(ref uni_student, ref school_student);



                choosingOption(ref uni_student, ref school_student);

                //=================//
            }

            void studentInputDetails(ref uniStudent uni_student, ref schoolStudent school_student)
            {

                Console.Write("Please enter your name:");
                uni_student.Name = Console.ReadLine();
                Console.Clear();

                Console.Write("Please enter your uni ID, it should be 6 digits long:");
                string Id = (Console.ReadLine());
                while (!isValidID(Id))
                {
                    Console.WriteLine("Invalid ID!");
                    Console.Write("Please try again:");
                    Console.Write("Please enter your school ID, it should be 6 digits long:");
                    Id = (Console.ReadLine());
                }
                uni_student.ID = Id;
                Console.WriteLine("Valid!");
                Console.ReadKey();
                Console.Clear();

                Console.Write("Please enter your Email:");
                string email = Console.ReadLine();
                while (!isValidEmail(email))
                {
                    Console.WriteLine("Invalid Email!");
                    Console.WriteLine("Please try again:");
                    Console.Write("Please enter your Email:");
                    email = Console.ReadLine();
                }
                uni_student.Email = email;
                Console.WriteLine("Valid!"); 
                Console.ReadKey();
                Console.Clear();

                Console.Write("Please enter your password, it should be at least 8 characters long (Digits & letters):");
                string password = Console.ReadLine();
                while (!isValidPassword(password))
                {
                    Console.WriteLine("Invalid Password!");
                    Console.WriteLine("Please try again:");
                    Console.Write("Please enter your password, it should be at least 8 characters long (Digits & letters):");
                    password = Console.ReadLine();

                }
                uni_student.Password = password;
                Console.WriteLine("Valid!");
                Console.ReadKey();
                Console.Clear();

                Console.WriteLine("Your info is saved succsesfully");
                Console.ReadKey();
                Console.Clear();
            }

            void choosingOption(ref uniStudent uni_student, ref schoolStudent school_student)
            {

                while (taskChoice != "4")
                {
                    Console.WriteLine("What do you want to do:");
                    Console.WriteLine("(1) Add a task");
                    Console.WriteLine("(2) Remove a task");
                    Console.WriteLine("(3) show tasks");
                    Console.WriteLine("(4) to exit!");
                    Console.WriteLine("==============");
                    Console.Write("Enter the number:");
                    taskChoice = Console.ReadLine();
                    Console.Clear();

                    switch (taskChoice)
                    {
                        case "1":
                            if (studiesChoice == 1)
                                uni_student.Add_Task();
                            else if (studiesChoice == 2)
                                school_student.Add_Task();
                            break;
                        case "2":
                            if (studiesChoice == 1)
                                uni_student.Remove_Task();
                            else if (studiesChoice == 2)
                                school_student.Remove_Task();
                            break;
                        case "3":
                            if (studiesChoice == 1)
                                uni_student.Show_Tasks();
                            else if (studiesChoice == 2)
                                school_student.Show_Tasks();
                            break;
                        case "4":
                            Console.WriteLine("Thanks for using the program,see you next time.");
                            Console.WriteLine();
                            break;
                        default:
                            Console.WriteLine("invalid number");
                            break;
                    }
                }
            }
            static bool isValidID(string ID)
            {
                if (ID.Length != 6)
                    return false;
                return true;
            }
            static bool isValidPassword(string password)
            {
                if (string.IsNullOrWhiteSpace(password))
                    return false;
                if (password.Length < 8)
                    return false;
                if (!password.Any(char.IsLetter))
                    return false;
                if (!password.Any(char.IsDigit))
                    return false;
                return true;
            }
            static bool isValidEmail(string email)
            {
                if (string.IsNullOrWhiteSpace(email))
                    return false;

                string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

                return Regex.IsMatch(email, pattern, RegexOptions.IgnoreCase);
            }
        }
    }
}
    
        